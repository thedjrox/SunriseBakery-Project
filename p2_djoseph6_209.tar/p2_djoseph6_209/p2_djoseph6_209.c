/* Danielle Joseph G01309421
CS 262, Lab Section 209
P2
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define SIZE 200

/*Funtion counts the number of cafe locations that is currently within the given distance from where it is and stores the value in its spot in the array. It is a grid of values.*/
void getGrid(int dx, int dy, int r, int n, int *distanceArr, int *x_cafeLoc, int *y_cafeLoc, int **grid, int numLoops){

	int i;
	int j;
	int z;

	for (i = 0; i < dx; i++){
	
		for(j = 0; j < dy; j++){
	
			for (z = 0; z < n; z++){
				/*uses distance formula to check if each cafe is within distance*/
				if ((abs((i+1) - x_cafeLoc[z]) + abs((j+1) - y_cafeLoc[z])) >= 0 && (abs((i+1) - x_cafeLoc[z]) + abs((j+1) - y_cafeLoc[z])) <= distanceArr[numLoops]){
		 
					grid[i][j]++;

				}		
			}			
		}
	}
}


/*Function finds the coordinates that contains the highest value in the grid (in other words the coordinates with most cafes within given distance)*/
void getOptimalLocation(int ** grid, int dx, int dy, FILE * output, int numLoops, int r, int *optimalLocX, int*optimalLocY){

	int i;
	int j;
	int highestNum; 
	highestNum = 0;
	/*initalize optimal coordinates with the first coordinates, add one because indexing starts at zero*/
	optimalLocX[numLoops] = 0 + 1;
        optimalLocY[numLoops] = 0 + 1;

	/*iterate through grid to find the highest number then find corresponding coordinates*/
	for (i = 0; i < dx; i++){
	
		for(j = 0; j < dy; j++){
		
			if (grid[i][j] > highestNum){
				
				highestNum = grid[i][j];
				optimalLocX[numLoops] = i + 1;
				optimalLocY[numLoops] = j + 1;
			}
		}
		
	}
	
	/*if there are multiple coordinates with the highestNum, choose the min-y coordinate as the first criterion and the min-x coordinate
as the second criterion*/
	for (i = 0; i < dx; i++){
		for(j = 0; j < dy; j++){

			if(grid[i][j] == highestNum){

                                if(j + 1 < optimalLocY[numLoops]){

                                        optimalLocX[numLoops] = i + 1;
                                        optimalLocY[numLoops] = j + 1;
                                }
                                else if (i + 1 < optimalLocY[numLoops]){

                                        optimalLocX[numLoops] = i + 1;
                                        optimalLocY[numLoops] = j + 1;

                                }
                        }
		}
	}

	/*if no coordinates is within distance of a cafe*/
	if(highestNum == 0){
	
        	fprintf(output, "-1(-1,-1)\n");
	}


	fprintf(output, "%i(%i,%i)\n", highestNum, optimalLocX[numLoops], optimalLocY[numLoops]);
}

/*Function prints a symbolic version of the grid with different symbols based on whats at the location*/
void printGrid(int n, int r, int dx, int dy, FILE * output, int**grid, int*x_cafeLoc, int*y_cafeLoc, int*optimalLocX, int*optimalLocY){

int i;
int j;
int z;
int m;
char character;
/*default value*/
character = '\0';

	for (j = dy; j > 0; j--){

		for(i = 0; i < dx; i++){

			for (z = 0; z < n; z++){

				/*if it is a cafe location*/
				if(i + 1 == x_cafeLoc[z] && j == y_cafeLoc[z]){

					character = '*';

				}
			}

			for (m = 0; m < r; m++){
				/*if it is both a cafe location and optimal location*/
				if(i + 1 == x_cafeLoc[m] && j == y_cafeLoc[m] && i +1 == optimalLocX[m] && j == optimalLocY[m]){
				
					character = '@';
						
				}

				if ( i + 1 == optimalLocX[m] && j == optimalLocY[m]){

					character = '$';

				}
			}
			/*if it has nothing in the location*/
			if(character != '$' && character != '*' && character != '@'){


				character = '-';

			}

			fprintf(output, "%c", character);
			/*rest character value*/
			character = '\0';
		}

		fprintf(output, "\n");

	}
}

int main(int argc, char **argv){
	/*declare variables*/
	char inBuf[SIZE];
	int dx;
	int dy;
	int n;
	int r;
	int i;
	int j;
	int numLoops;
	FILE * input;
	FILE * output;
	int *x_cafeLoc;
        int *y_cafeLoc;
	int * distanceArr;
        int ** grid;
	int *optimalLocX;
        int * optimalLocY;
	int instances;
	instances = 0;
	numLoops = 0;

	/*if number of arguments from the user is less than two*/
	if(argc < 2){

		printf("Error! You must specify input filename: %s <input_filename>\n", argv[0]);
		exit(1);
	}
	/* if inputfile isn't the right text*/
	if (strcmp(argv[1], "sunrise_c1.txt") != 0){
		
		printf("Error! The %s file can’t be opened\n", argv[1]);
		exit(1);
	}

	input = fopen("sunrise_c1.txt", "r");

	if (input == NULL){
	printf("Error! The %s file can’t be opened\n", argv[1]);
		exit(1);

	}
	
	/*creates output file*/
	output = fopen("sunrise_c1.out", "w");

        if (output == NULL){
        printf("Error! The sunrise_c1.out file can’t be opened\n");
                exit(1);

        }

	printf("Output file: sunrise_c1.out created successfully\n");

	/*checks if the input file contains any text, if not, end the program*/
	if (fgets(inBuf, SIZE, input) == NULL){
		fclose(input);
        	fclose(output);
		return 1;		
	}

	/*do while loop to go through all the instances in the input file*/
	do{


        	sscanf(inBuf, "%i %i %i %i\n", &dx, &dy, &n, &r);

		/* allocates memory for all arrays to be used*/
		optimalLocX = (int*)malloc(r * sizeof(int));
        	if (optimalLocX == NULL){

                	exit(1);
        	}
        	optimalLocY = (int*)malloc(r * sizeof(int));
        	if (optimalLocY == NULL){

                	exit(1);
        	}

        	x_cafeLoc = (int*)malloc(n * sizeof(int));
        	if (x_cafeLoc == NULL){

                	exit(1);
        	}
        	y_cafeLoc = (int*)malloc(n * sizeof(int));
        	if (y_cafeLoc == NULL){

                	exit(1);
        	}

        	grid = (int**)malloc(sizeof(int *) * dx);
        	if(grid == NULL){

                	exit(1);
        	}

		for(i = 0; i < dx; i++){

                	grid[i] = (int*)malloc(dy * sizeof(int));
                	if( grid[i] == NULL){

                        	exit(1);
                	}
        	}

        	distanceArr = (int*)malloc(r * sizeof(int));
        	if(distanceArr == NULL){

                	exit(1);
        	}

		for(i = 0; i < n; i++){
	
			fgets(inBuf, SIZE, input);
                	sscanf(inBuf, "%i %i\n", &x_cafeLoc[i], &y_cafeLoc[i]);
        	}


        	for(i = 0; i < r; i++){

                	fgets(inBuf, SIZE, input);
                	sscanf(inBuf, "%i\n", &distanceArr[i]);
		}

		/*resets grid values back to zero*/
		for (i = 0; i < dx; i++){

              		for(j = 0; j < dy; j++){

                        	grid[i][j] = 0;
                        }
                }

		instances++;

		fprintf(output, "Instance %i:\n", instances);

		/*iterates through all the survey reponses to get the optimal coordinates*/
		while (numLoops < r){

			getGrid(dx, dy, r, n, distanceArr, x_cafeLoc, y_cafeLoc, grid, numLoops);
			getOptimalLocation(grid, dx, dy, output, numLoops, r, optimalLocX, optimalLocY);
			/* resets grid values to zero*/
			for (i = 0; i < dx; i++){

                		for(j = 0; j < dy; j++){

                        		grid[i][j] = 0;
               			}	
        		}

			numLoops++;
		}

		printGrid(n, r, dx, dy, output, grid, x_cafeLoc, y_cafeLoc, optimalLocX, optimalLocY);
		/*reset numLoops*/
		numLoops = 0;

		/* read the line that indicates end of test case instance*/
		fgets(inBuf, SIZE, input);
		
		/*free any dynamically allocated memory*/
		free(x_cafeLoc);
        	free(y_cafeLoc);
        	free(distanceArr);
        	free(optimalLocX);
        	free(optimalLocY);
        	for(i = 0; i < dx; i++){
                	free(grid[i]);
        	}
        	free(grid);

	}
	/*until end of input file is reached*/
	while(fgets(inBuf, SIZE, input) != NULL);

	fclose(input);
	fclose(output);

	return 1;

}
